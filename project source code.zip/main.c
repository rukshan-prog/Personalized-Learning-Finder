//
//  Created by Rasintha_Rukshan on 17/12/2024..
//

#include <course_recommendation.h>


int main() {

    // start the application
    run();

    return 0;
}