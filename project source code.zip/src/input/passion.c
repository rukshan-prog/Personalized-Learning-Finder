//
// Created by [isuru] on [date].
//

#include <input.h>



// get passion from the user
char* getPassion() {
    char *passion;
    passion = getString("Enter Your Passion");
    return passion;
}