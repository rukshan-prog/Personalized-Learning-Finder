//
// Created by nethsara on 23/12/2024.
//

#ifndef PERSONALIZED_LEARNING_FINDER_USER_H
#define PERSONALIZED_LEARNING_FINDER_USER_H

#include <user.h>
#include <course_recommendation.h>

void getUserData(UserData *userData);

#endif //PERSONALIZED_LEARNING_FINDER_USER_H
