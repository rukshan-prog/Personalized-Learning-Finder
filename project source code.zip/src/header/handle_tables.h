//
// Created by Rasintha_Rukshan on 23/12/2024.
//

#ifndef PERSONALIZED_LEARNING_FINDER_CREATE_TABLES_H
#define PERSONALIZED_LEARNING_FINDER_CREATE_TABLES_H


bool create_tables();
bool drop_tables();


#endif //PERSONALIZED_LEARNING_FINDER_CREATE_TABLES_H
