//
// Created by isuru on 20/01/2025.
//

#ifndef PERSONALIZED_LEARNING_FINDER_ERRRORLOG_H
#define PERSONALIZED_LEARNING_FINDER_ERRRORLOG_H

void logError(const char *message);

void readErrors();

#endif //PERSONALIZED_LEARNING_FINDER_ERRRORLOG_H
