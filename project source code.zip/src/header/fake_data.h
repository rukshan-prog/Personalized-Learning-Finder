//
// Created by Rasintha_Rukshan on 03/01/2025.
//

#ifndef PERSONALIZED_LEARNING_FINDER_FAKE_DATA_H
#define PERSONALIZED_LEARNING_FINDER_FAKE_DATA_H

bool add_fake_data();

#endif //PERSONALIZED_LEARNING_FINDER_FAKE_DATA_H
