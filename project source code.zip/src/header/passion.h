//
// Created by [your name] on [date].
//

#ifndef PERSONALIZED_LEARNING_FINDER_PASSION_H
#define PERSONALIZED_LEARNING_FINDER_PASSION_H

char* getPassion();

#endif //PERSONALIZED_LEARNING_FINDER_PASSION_H
